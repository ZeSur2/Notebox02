NoteBox
1. Create a new GitHub repo and upload everything in this folder (keep the .github folder).
2. Wait ~5 min: repo > Actions tab > "Build APK" finishes.
3. Repo > Releases > download app-debug.apk on your phone and install it.
