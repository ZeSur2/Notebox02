package com.notebox.sync

import android.content.Context
import com.notebox.data.NoteDatabase
import kotlinx.coroutines.flow.first
import androidx.glance.appwidget.updateAll
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object BackupManager {
    fun backupDir(ctx: Context) = File(ctx.filesDir, "backups").apply { mkdirs() }

    suspend fun backupNow(ctx: Context): File? = try {
        val notes = NoteDatabase.get(ctx).noteDao().observeAll().first()
        val arr = JSONArray()
        notes.forEach { n ->
            arr.put(JSONObject().apply {
                put("id", n.id); put("title", n.title); put("content", n.content)
                put("folder", n.folder); put("imagePath", n.imagePath ?: "")
                put("customBgColor", n.customBgColor ?: -1)
                put("customTextColor", n.customTextColor ?: -1)
                put("widgetFontScale", n.widgetFontScale.toDouble())
                put("pinned", n.pinned)
                put("createdAt", n.createdAt); put("updatedAt", n.updatedAt)
            })
        }
        val file = File(backupDir(ctx), "notebox-${System.currentTimeMillis()}.json")
        file.writeText(arr.toString()); file
    } catch (e: Exception) { null }

    suspend fun restoreLatest(ctx: Context): Int? = try {
        val latest = backupDir(ctx).listFiles()?.maxByOrNull { it.lastModified() } ?: return null
        val arr = JSONArray(latest.readText()); var count = 0
        val existing = NoteDatabase.get(ctx).noteDao().observeAll().first()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val dup = existing.any { it.createdAt == o.optLong("createdAt", -1L) && it.title == o.getString("title") }
            if (dup) continue
            val bg = o.optLong("customBgColor", -1).takeIf { it >= 0 }
            val txt = o.optLong("customTextColor", -1).takeIf { it >= 0 }
            NoteDatabase.get(ctx).noteDao().upsert(com.notebox.data.Note(
                id = 0,
                title = o.getString("title"), content = o.getString("content"),
                folder = o.optString("folder", "Inbox"),
                imagePath = o.optString("imagePath").takeIf { it.isNotBlank() },
                customBgColor = bg, customTextColor = txt,
                widgetFontScale = o.optDouble("widgetFontScale", 1.0).toFloat(),
                pinned = o.optBoolean("pinned", false),
                createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                updatedAt = o.optLong("updatedAt", System.currentTimeMillis())
            )); count++
        }
        com.notebox.widget.NoteBoxWidget().updateAll(ctx)
        count
    } catch (e: Exception) { null }
}
