package com.notebox.widget

import android.content.Context
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.cornerRadius
import androidx.glance.action.clickable
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.*
import androidx.glance.text.*
import androidx.glance.unit.ColorProvider
import com.notebox.MainActivity
import com.notebox.data.ImageStore
import com.notebox.data.Note
import com.notebox.data.NoteDatabase
import com.notebox.data.Prefs

class NoteBoxWidget : GlanceAppWidget() {
    override val sizeMode = SizeMode.Responsive(setOf(
        DpSize(100.dp, 100.dp), DpSize(160.dp, 100.dp), DpSize(250.dp, 100.dp),
        DpSize(100.dp, 200.dp), DpSize(160.dp, 200.dp), DpSize(250.dp, 200.dp),
        DpSize(250.dp, 280.dp), DpSize(320.dp, 280.dp)))

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val dao = NoteDatabase.get(context).noteDao()
        val note: Note? = dao.getPinned() ?: dao.getLatest()
        val folderBg = note?.let { Prefs.getFolderBg(context, it.folder) }
        val folderText = note?.let { Prefs.getFolderText(context, it.folder) }
        val bg = note?.customBgColor ?: folderBg ?: Prefs.getDefaultBg(context)
        val text = note?.customTextColor ?: folderText ?: Prefs.getDefaultText(context)

        provideContent {
            val size = LocalSize.current
            val bgColor = Color(bg); val textColor = Color(text)
            Column(
                modifier = GlanceModifier.fillMaxSize()
                    .background(ColorProvider(bgColor)).padding(10.dp)
                    .clickable(actionStartActivity(android.content.Intent(context, MainActivity::class.java))),
                verticalAlignment = Alignment.Top) {
                if (note == null) {
                    Text("NoteBox\nno notes", style = TextStyle(
                        fontFamily = androidx.glance.text.FontFamily.Monospace,
                        fontSize = 13.sp, color = ColorProvider(textColor)))
                } else {
                    Text(note.title.ifBlank { "(untitled)" }, style = TextStyle(
                        fontFamily = androidx.glance.text.FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = pickFont(note.title.ifBlank { "(untitled)" },
                            size.width, size.height * 0.20f, 20f, 11f,
                            note.widgetFontScale, 2).sp,
                        color = ColorProvider(textColor)), maxLines = 2)
                    Spacer(GlanceModifier.height(6.dp))
                    val showImage = note.imagePath != null &&
                            size.height.value >= 180f && size.width.value >= 140f
                    val imageReserve = if (showImage) size.height * 0.42f else 0.dp
                    val bodyHeight = (size.height - imageReserve - size.height * 0.28f)
                        .coerceAtLeast(20.dp)
                    val bodyFont = pickFont(note.content, size.width, bodyHeight,
                        18f, 9f, note.widgetFontScale, 0)
                    Text(note.content.ifBlank { "—" }, style = TextStyle(
                        fontFamily = androidx.glance.text.FontFamily.Monospace,
                        fontSize = bodyFont.sp, color = ColorProvider(textColor)),
                        maxLines = estimateLines(note.content, bodyFont, size.width, bodyHeight))
                    if (showImage) {
                        val file = ImageStore.resolve(context, note.imagePath!!)
                        if (file.exists()) {
                            val bitmap = loadScaled(file.absolutePath)
                            if (bitmap != null) {
                                Spacer(GlanceModifier.height(6.dp))
                                Image(provider = ImageProvider(bitmap), contentDescription = null,
                                    modifier = GlanceModifier.fillMaxWidth().height(imageReserve)
                                        .cornerRadius(8.dp), contentScale = ContentScale.Crop)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun loadScaled(path: String, maxDim: Int = 480): android.graphics.Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (bounds.outWidth / sample > maxDim * 2 || bounds.outHeight / sample > maxDim * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val b = BitmapFactory.decodeFile(path, opts) ?: return null
        val scale = maxDim.toFloat() / maxOf(b.width, b.height)
        return if (scale < 1f) android.graphics.Bitmap.createScaledBitmap(
            b, (b.width * scale).toInt().coerceAtLeast(1),
            (b.height * scale).toInt().coerceAtLeast(1), true) else b
    }

    private fun pickFont(text: String, widthDp: Dp, heightDp: Dp, maxSp: Float,
                        minSp: Float, userScale: Float, linesFixed: Int): Float {
        val max = (maxSp * userScale).coerceAtLeast(minSp)
        var size = max
        val safeText = text.ifBlank { " " }
        while (size >= minSp) {
            val cpl = (widthDp.value / (size * 0.60f)).toInt().coerceAtLeast(1)
            val needed = if (linesFixed > 0) linesFixed else (safeText.length / cpl) + 1
            val fits = (heightDp.value / (size * 1.35f)).toInt().coerceAtLeast(1)
            if (needed <= fits) return size
            size -= 0.5f
        }
        return minSp
    }

    private fun estimateLines(text: String, fontSize: Float, width: Dp, height: Dp): Int {
        val cpl = (width.value / (fontSize * 0.60f)).toInt().coerceAtLeast(1)
        val maxLines = (height.value / (fontSize * 1.35f)).toInt().coerceAtLeast(1)
        val needed = if (text.isEmpty()) 1 else (text.length / cpl) + 1
        return minOf(needed, maxLines).coerceAtLeast(1)
    }
}
