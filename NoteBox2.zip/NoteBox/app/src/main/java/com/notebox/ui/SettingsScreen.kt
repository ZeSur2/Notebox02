package com.notebox.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.glance.appwidget.updateAll
import com.notebox.data.Prefs
import com.notebox.widget.NoteBoxWidget
import com.notebox.sync.BackupManager
import com.notebox.sync.WebDavClient
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onBack)
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("") }
    var defaultBg by remember { mutableStateOf(0xFF272822L) }
    var defaultText by remember { mutableStateOf(0xFFF8F8F2L) }
    LaunchedEffect(Unit) {
        defaultBg = Prefs.getDefaultBg(ctx); defaultText = Prefs.getDefaultText(ctx)
    }
    var davUrl by remember { mutableStateOf("") }
    var davUser by remember { mutableStateOf("") }
    var davPass by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        val c = Prefs.getWebDav(ctx); davUrl = c.url; davUser = c.user; davPass = c.pass
    }
    Scaffold(topBar = { TopAppBar(title = { Text("~/settings") },
        navigationIcon = { IconButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, contentDescription = "Back") } }) }) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("default widget colors", style = MaterialTheme.typography.titleLarge)
            Text("background", style = MaterialTheme.typography.labelSmall)
            Swatches(defaultBg) { defaultBg = it; scope.launch { Prefs.setDefaultBg(ctx, it); NoteBoxWidget().updateAll(ctx) } }
            Text("text", style = MaterialTheme.typography.labelSmall)
            Swatches(defaultText) { defaultText = it; scope.launch { Prefs.setDefaultText(ctx, it); NoteBoxWidget().updateAll(ctx) } }
            HorizontalDivider()
            Text("backup", style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { scope.launch {
                    status = BackupManager.backupNow(ctx)?.let { "saved: ${it.name}" } ?: "backup failed"
                } }) { Text("backup now") }
                OutlinedButton(onClick = { scope.launch {
                    status = BackupManager.restoreLatest(ctx)?.let { "restored $it notes" } ?: "no backups"
                } }) { Text("restore latest") }
            }
            HorizontalDivider()
            Text("WebDAV cloud sync", style = MaterialTheme.typography.titleLarge)
            OutlinedTextField(davUrl, { davUrl = it }, label = { Text("server URL") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(davUser, { davUser = it }, label = { Text("username") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(davPass, { davPass = it }, label = { Text("password") },
                singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { scope.launch {
                    Prefs.setWebDav(ctx, davUrl, davUser, davPass); status = "webdav saved"
                } }) { Text("save") }
                Button(onClick = { scope.launch {
                    Prefs.setWebDav(ctx, davUrl, davUser, davPass)
                    val c = WebDavClient(davUrl, davUser, davPass)
                    status = if (c.uploadLatest(ctx)) "uploaded ✓" else "upload failed"
                } }) { Text("upload latest") }
                OutlinedButton(onClick = { scope.launch {
                    val c = WebDavClient(davUrl, davUser, davPass)
                    status = if (c.downloadLatest(ctx)) "downloaded ✓" else "download failed"
                } }) { Text("download latest") }
            }
            if (status.isNotBlank()) Text("status: $status",
                style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(24.dp))
        }
    }
}

private val SwatchSet = listOf(0xFF272822L, 0xFF1E1F1C, 0xFF0F1115L, 0xFF2B213AL,
    0xFFA6E22EL, 0xFF66D9EFL, 0xFFF92672L, 0xFFFD971FL, 0xFFF8F8F2L, 0xFFD4D4D4L, 0xFFFFFFFFL)

@Composable
private fun Swatches(selected: Long, onPick: (Long) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        SwatchSet.forEach { c ->
            Box(Modifier.size(28.dp).background(Color(c))
                .border(if (selected == c) 2.dp else 1.dp,
                    if (selected == c) MaterialTheme.colorScheme.primary else Color.Gray)
                .clickable { onPick(c) })
        }
    }
}
