package com.notebox.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notes")
data class Note(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val content: String = "",
    val folder: String = "Inbox",
    val imagePath: String? = null,
    val customBgColor: Long? = null,
    val customTextColor: Long? = null,
    val widgetFontScale: Float = 1.0f,
    val pinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
